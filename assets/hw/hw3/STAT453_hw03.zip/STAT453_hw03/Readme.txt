This assignment involves working with multiple files and reading a large number of images. Please read the instructions in hw3.ipynb carefully and complete the tasks in order.
You may first run the notebook without modifying any code to observe the workflow, and then complete the required tasks after understanding the code.
Since the dataset contains a large number of images, it is recommended to use a GPU to speed up computation.
It’s also advised to start early, as the algorithms may take a long time to run and could delay your submission.
(If, after running the data preparation file, the images fail to sync properly, you can try using the png-files folder to skip some of the steps.)